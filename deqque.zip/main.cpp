#define CATCH_CONFIG_MAIN
#include "deque.h"
#include "catch2/catch.hpp"
//int main(){
	/*int a = 1;
	Deque testin;
	Deque *deq = new Deque;
	testin.PushFront(1);
	testin.PushFront(2);
	testin.PushFront(3);
	printf("%d",testin.Length() );
	std::cout << testin.Length() << std::endl;
	testin.PopBack();
	std::cout << testin.Length() << std::endl;*/		
/*for( testin.begin(); it != testin.end(); it++){
std::cout << (*it) << "   ";
}*/
//	return 0;
//}
